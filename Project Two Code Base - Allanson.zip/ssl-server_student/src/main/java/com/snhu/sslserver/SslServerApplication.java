// SslServerApplication.java
// Landon Allanson

package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {
	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
}

@RestController
class ServerController {

	@GetMapping("/hash")
	public String myHash() throws NoSuchAlgorithmException {
		String data = "Hello World Check Sum! Landon Allanson - Artemis Financial secure data verification";

		MessageDigest md = MessageDigest.getInstance("SHA-256");
		byte[] hash = md.digest(data.getBytes(StandardCharsets.UTF_8));

		StringBuilder checksum = new StringBuilder();
		for (byte b : hash) {
			checksum.append(String.format("%02x", b));
		}

		return "<p>Data: " + data + "</p>" + "<p>Name of Cipher Algorithm Used: SHA-256</p>" + "<p>CheckSum Value: "
				+ checksum + "</p>";
	}
}